define(['./dist/qdp-report-trigger'], (supernova) => supernova);
